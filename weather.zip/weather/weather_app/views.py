import json
import urllib.request
from django.shortcuts import render

def home(request):
    if request.method == 'POST':
        # Get the city name from the user
        city = request.POST.get('city', 'True')
        
        # Retrieve the information using the API
        try:
            source = urllib.request.urlopen('http://api.openweathermap.org/data/2.5/weather?q=' + city + '&units=imperial&appid=a79f0ac7984d983086b87622faacc144').read()
            # Convert JSON data file into Python dictionary
            list_of_data = json.loads(source)
            
            # Create dictionary and convert values to string
            context = {
                'city': city,
                "country_code": str(list_of_data['sys']['country']),
                "coordinate": str(list_of_data['coord']['lon']) + ' ' + str(list_of_data['coord']['lat']),
                "temp": str(list_of_data['main']['temp']) + '°F',
                "pressure": str(list_of_data['main']['pressure']) + ' hPa',
                "humidity": str(list_of_data['main']['humidity']) + '%',
            }
        except Exception as e:
            context = {'error': 'Could not retrieve data for the specified city.'}
    else:
        context = {}
    
    # Send dictionary to the index.html
    return render(request, 'index.html', context)
